package com.example.jetpackcomposedemo

import androidx.compose.runtime.*

@Composable
fun DropdownDemoApp() {
    var showDropdownScreen by remember { mutableStateOf(false) }

    if (showDropdownScreen) {
        FruitDropdownDemo(onNavigateUp = { showDropdownScreen = false })
    } else {
        MainScreen(onDropdownClick = { showDropdownScreen = true })
    }
}
package com.example.jetpackcomposedemo

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.semantics.SemanticsProperties // Required for set(SemanticsProperties.Role, Role.DropdownList)
import androidx.compose.ui.semantics.heading // Added import

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StandardFruitDropdown(fruits: List<String>, modifier: Modifier = Modifier) {
    var expanded by remember { mutableStateOf(false) }
    var selectedFruit by remember { mutableStateOf(fruits.getOrElse(0) { "" }) }

    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = "커스텀 버튼 + DropdownMenu",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.semantics { heading() }
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text("과일을 선택하세요:", style = MaterialTheme.typography.bodyLarge)
        Spacer(modifier = Modifier.height(8.dp))

        Box {
            Button(
                onClick = { expanded = !expanded },
                modifier = Modifier.semantics {
                    set(SemanticsProperties.Role, Role.DropdownList)
                }
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(selectedFruit)
                    Icon(
                        imageVector = if (expanded) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                        contentDescription = null // Accessibility handled by Button's role
                    )
                }
            }

            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                fruits.forEach { fruit ->
                    DropdownMenuItem(
                        text = {
                            Text(
                                text = fruit,
                                fontWeight = if (fruit == selectedFruit) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier.then(
                                    if (fruit == selectedFruit) {
                                        Modifier.semantics { selected = true }
                                    } else {
                                        Modifier
                                    }
                                )
                            )
                        },
                        onClick = {
                            selectedFruit = fruit
                            expanded = false
                        }
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text("선택된 과일: $selectedFruit", style = MaterialTheme.typography.bodyLarge)
    }
}

@Preview(showBackground = true)
@Composable
fun StandardFruitDropdownPreview() {
    val sampleFruits = listOf("사과", "바나나", "체리", "포도")
    MaterialTheme {
        StandardFruitDropdown(fruits = sampleFruits)
    }
}

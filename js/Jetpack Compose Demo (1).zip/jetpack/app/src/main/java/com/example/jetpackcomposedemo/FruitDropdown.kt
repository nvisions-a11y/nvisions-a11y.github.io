package com.example.jetpackcomposedemo

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.paneTitle
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.activity.compose.BackHandler
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FruitDropdownDemo(onNavigateUp: () -> Unit) {
    val fruits = listOf(
        "사과", "바나나", "체리", "날짜", "엘더베리",
        "무화과", "포도", "허니듀", "키위", "레몬",
        "망고", "오렌지", "파파야", "복숭아", "배",
        "파인애플", "자두", "딸기", "수박", "라즈베리"
    )

    // 모달 상태 관리
    var showModal by remember { mutableStateOf(false) }
    var modalItems by remember { mutableStateOf(emptyList<String>()) }
    var modalSelectedItem by remember { mutableStateOf("") }
    var modalOnItemSelected by remember { mutableStateOf<(String) -> Unit>({}) }
    var dropdownFocusRequester by remember { mutableStateOf<FocusRequester?>(null) }

    BackHandler(enabled = showModal) { // 모달이 열려있을 때 뒤로 가기 처리
        showModal = false
    }

    BackHandler(enabled = !showModal) { // 모달이 닫혀있을 때 메인 화면 뒤로 가기
        onNavigateUp()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .semantics {
                paneTitle = "드롭다운 데모"
            }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("드롭다운 데모") },
                    navigationIcon = {
                        IconButton(
                            onClick = {
                                if (showModal) {
                                    // 모달이 열려있을 때: 모달만 닫기
                                    showModal = false
                                } else {
                                    // 모달이 닫혀있을 때: 이전 화면으로 이동
                                    onNavigateUp()
                                }
                            }
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "뒤로 가기")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                        titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        navigationIconContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                )
            }
        ) { paddingValues ->
            // 모든 드롭다운(4개)을 감싸는 컨테이너 (모달이 열렸을 때 접근성에서 제외)
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(16.dp)
                    .then(
                        if (showModal) {
                            // 모달이 열렸을 때: 모든 드롭다운을 접근성 트리에서 제외
                            Modifier.clearAndSetSemantics { }
                        } else {
                            // 모달이 닫혔을 때: 정상 접근성 유지
                            Modifier
                        }
                    ),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                StandardFruitDropdown(fruits = fruits)

                NonSearchableExposedDropdown(fruits = fruits)

                SearchableExposedDropdown(fruits = fruits)

                CustomFruitDropdown(
                    fruits = fruits,
                    onModalRequest = { show, items, selectedItem, onItemSelected ->
                        showModal = show
                        modalItems = items
                        modalSelectedItem = selectedItem
                        modalOnItemSelected = onItemSelected
                    },
                    onFocusRequesterReady = { focusRequester ->
                        dropdownFocusRequester = focusRequester
                    }
                )
            }
        }

        // 전체 화면을 덮는 모달
        if (showModal) {
            FullyCustomDropdownModal(
                items = modalItems,
                selectedItem = modalSelectedItem,
                onItemSelected = { selectedItem ->
                    println("FruitDropdownDemo: 아이템 선택됨 - $selectedItem")
                    modalOnItemSelected(selectedItem)
                    showModal = false
                },
                onDismissRequest = { 
                    println("FruitDropdownDemo: 모달 dismiss")
                    showModal = false
                }
            )
        }
    }

    // 모달이 닫힐 때 항상 포커스 복귀 처리
    LaunchedEffect(showModal) {
        if (!showModal && dropdownFocusRequester != null) {
            delay(250) // UI 안정화를 위한 최소 딜레이
            try {
                println("FruitDropdownDemo: 포커스 복귀 시도 - $dropdownFocusRequester")
                dropdownFocusRequester?.requestFocus()
                println("FruitDropdownDemo: 포커스 복귀 완료")
            } catch (e: Exception) {
                println("FruitDropdownDemo: 포커스 요청 실패 - ${e.message}")
            }
        }
    }
}

@Preview
@Composable
fun FruitDropdownDemoPreview() {
    MaterialTheme {
        FruitDropdownDemo(onNavigateUp = {})
    }
} 
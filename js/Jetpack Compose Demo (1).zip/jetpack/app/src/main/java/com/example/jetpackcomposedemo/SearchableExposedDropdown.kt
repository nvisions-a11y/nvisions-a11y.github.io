package com.example.jetpackcomposedemo

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchableExposedDropdown(fruits: List<String>, modifier: Modifier = Modifier) {
    var expanded by remember { mutableStateOf(false) }
    var selectedFruitText by remember { mutableStateOf(fruits.getOrElse(0) { "" }) }
    // searchText is the text currently in the TextField, can be different from selectedFruitText
    var searchText by remember { mutableStateOf(fruits.getOrElse(0) { "" }) }

    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current

    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = "ExposedDropdownMenu (검색 가능)",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.semantics { heading() }
        )
        Spacer(modifier = Modifier.height(8.dp))
        ExposedDropdownMenuBox(
            expanded = expanded,
            onExpandedChange = {
                expanded = !expanded
                if (expanded) {
                    // When opening, searchText should allow typing, so it can be empty or current selection
                    // searchText = "" // Option 1: Clear search text when opening
                    // Option 2: Keep selected fruit text, user can then clear it
                } else {
                    // When closing, reset searchText to the actual selected fruit
                    searchText = selectedFruitText
                    focusManager.clearFocus()
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            TextField(
                modifier = Modifier.menuAnchor().fillMaxWidth(),
                value = searchText,
                onValueChange = {
                    searchText = it
                    expanded = true // Keep dropdown open while typing if it's not empty
                },
                label = { Text("과일 검색 및 선택") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                colors = ExposedDropdownMenuDefaults.textFieldColors()
            )

            val filteredFruits = if (searchText.isEmpty() || searchText == selectedFruitText) {
                fruits // Show all fruits if search is empty or matches current selection
            } else {
                fruits.filter { it.contains(searchText, ignoreCase = true) }
            }

            if (filteredFruits.isNotEmpty()) {
                ExposedDropdownMenu(
                    expanded = expanded,
                    onDismissRequest = {
                        expanded = false
                        searchText = selectedFruitText // Reset to selected on dismiss
                        focusManager.clearFocus()
                    }
                ) {
                    filteredFruits.forEach { fruit ->
                        val isSelected = fruit == selectedFruitText
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = fruit,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            onClick = {
                                selectedFruitText = fruit
                                searchText = fruit // Update searchText to reflect selection
                                expanded = false
                                focusManager.clearFocus()
                                keyboardController?.hide()
                            },
                            modifier = Modifier.semantics {
                                if (isSelected) this.selected = true
                            },
                            contentPadding = ExposedDropdownMenuDefaults.ItemContentPadding
                        )
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text("선택된 과일: $selectedFruitText", style = MaterialTheme.typography.bodyLarge)
    }
}

@Preview(showBackground = true)
@Composable
fun SearchableExposedDropdownPreview() {
    val sampleFruits = listOf("Apple", "Banana", "Cherry", "Date", "Elderberry", "Fig", "Grape")
    MaterialTheme {
        SearchableExposedDropdown(fruits = sampleFruits)
    }
}

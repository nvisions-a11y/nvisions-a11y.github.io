package com.example.jetpackcomposedemo

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowDropUp
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

@Composable
fun CustomFruitDropdown(
    fruits: List<String>, 
    modifier: Modifier = Modifier,
    onModalRequest: (Boolean, List<String>, String, (String) -> Unit) -> Unit = { _, _, _, _ -> },
    onFocusRequesterReady: (FocusRequester) -> Unit = {}
) {
    var selectedFruit by remember { mutableStateOf(fruits.firstOrNull() ?: "") }
    val dropdownFocusRequester = remember { FocusRequester() }

    // FocusRequester를 부모에게 전달
    LaunchedEffect(dropdownFocusRequester) {
        println("CustomFruitDropdown: FocusRequester 준비 완료 - $dropdownFocusRequester")
        onFocusRequesterReady(dropdownFocusRequester)
    }

    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = "완전 커스텀 드롭다운 (앵커 + 모달)",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.semantics { heading() }
        )
        Spacer(modifier = Modifier.height(8.dp))
        FullyCustomDropdownAnchor(
            label = "과일 선택 (커스텀)",
            selectedItem = selectedFruit,
            expanded = false,
            onClick = { 
                onModalRequest(true, fruits, selectedFruit) { newFruit ->
                    selectedFruit = newFruit
                }
            },
            focusRequester = dropdownFocusRequester
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text("선택된 과일: $selectedFruit", style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
fun FullyCustomDropdownAnchor(
    label: String,
    selectedItem: String,
    expanded: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    focusRequester: FocusRequester = remember { FocusRequester() }
) {
    val interactionSource = remember { MutableInteractionSource() }
    Box(
        modifier = modifier
            .fillMaxWidth()
            .focusRequester(focusRequester) // focusRequester를 clickable 앞에 위치
            .focusable() // 포커스 수신 가능하도록 설정
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outline,
                shape = MaterialTheme.shapes.extraSmall
            )
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .semantics {
                this.onClick(label = "${label}, ${if (expanded) "드롭다운 닫기" else "드롭다운 열기"}") { onClick(); true }
                set(SemanticsProperties.Role, Role.DropdownList)
            }
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = if (selectedItem.isEmpty()) label else selectedItem,
                style = MaterialTheme.typography.bodyLarge,
                color = if (selectedItem.isEmpty()) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
            )
            Icon(
                imageVector = if (expanded) Icons.Filled.ArrowDropUp else Icons.Filled.ArrowDropDown,
                contentDescription = null
            )
        }
    }
}

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun FullyCustomDropdownModal(
    items: List<String>,
    selectedItem: String,
    onItemSelected: (String) -> Unit,
    onDismissRequest: () -> Unit
) {
    val configuration = LocalConfiguration.current

    // BackHandler는 FruitDropdown.kt에서 중앙집중식으로 관리
    
    // Scrim Box: 화면을 채우고, 배경색을 지정하며, 외부 탭 시 닫힘 처리
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.4f)) // 스크림 효과
            .pointerInput(Unit) { // 모달 외부 탭 시 닫힘
                detectTapGestures(onTap = { onDismissRequest() })
            }
    ) {
        // 드롭다운 패널 컨테이너
        Box(
            modifier = Modifier
                .align(Alignment.Center) // Scrim 내에서 중앙 정렬
                .widthIn(max = 280.dp) // 패널 너비 제한
                .heightIn(max = (configuration.screenHeightDp * 0.6).dp) // 패널 최대 높이 제한
                .background(MaterialTheme.colorScheme.surface) // 패널 컨테이너 배경색
                .clickable( // 패널 클릭이 Scrim으로 전파되는 것 방지
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = { /* 클릭 이벤트 소비 */ }
                )
        ) {
            Surface( // 실제 콘텐츠를 담는 Surface
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                Column {
                    // 스크롤 가능한 아이템 목록 (닫기 버튼 제거됨)
                    Column(
                        modifier = Modifier
                            .padding(vertical = 16.dp) // 상단 패딩 증가
                            .verticalScroll(rememberScrollState())
                    ) {
                        items.forEach { item ->
                            val isSelected = item == selectedItem
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        onItemSelected(item)
                                    }
                                    .padding(horizontal = 16.dp, vertical = 12.dp)
                                    .semantics {
                                        if (isSelected) {
                                            this.selected = true
                                        }
                                    },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = item,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                )
                                if (isSelected) {
                                    Spacer(Modifier.weight(1f))
                                    Icon(
                                        Icons.Filled.Check,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun CustomFruitDropdownPreview() {
    val sampleFruits = listOf("사과", "바나나", "체리", "포도")
    
    var showModal by remember { mutableStateOf(false) }
    var modalItems by remember { mutableStateOf(emptyList<String>()) }
    var modalSelectedItem by remember { mutableStateOf("") }
    var modalOnItemSelected by remember { mutableStateOf<(String) -> Unit>({}) }
    var dropdownFocusRequester by remember { mutableStateOf<FocusRequester?>(null) }

    MaterialTheme {
        Box(Modifier.fillMaxSize()) {
            CustomFruitDropdown(
                fruits = sampleFruits,
                onModalRequest = { show, items, selectedItem, onItemSelected ->
                    showModal = show
                    modalItems = items
                    modalSelectedItem = selectedItem
                    modalOnItemSelected = onItemSelected
                },
                onFocusRequesterReady = { focusRequester ->
                    dropdownFocusRequester = focusRequester
                }
            )

            if (showModal) {
                FullyCustomDropdownModal(
                    items = modalItems,
                    selectedItem = modalSelectedItem,
                    onItemSelected = { selectedItem ->
                        modalOnItemSelected(selectedItem)
                        showModal = false
                    },
                    onDismissRequest = { 
                        showModal = false
                    }
                )
            }
        }
    }
} 
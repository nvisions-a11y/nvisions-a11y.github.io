"use client";

import { useState } from "react";
import * as Checkbox from "@radix-ui/react-checkbox";
import * as Dialog from "@radix-ui/react-dialog";
import * as Label from "@radix-ui/react-label";
import * as Separator from "@radix-ui/react-separator";

const fruits = [
  "사과", "바나나", "오렌지", "딸기", "포도", 
  "키위", "망고", "복숭아", "체리", "수박"
];

export default function Home() {
  const [selectedFruits, setSelectedFruits] = useState<string[]>([]);
  const [confirmedFruits, setConfirmedFruits] = useState<string[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const handleFruitChange = (fruit: string, checked: boolean) => {
    if (checked) {
      setSelectedFruits([...selectedFruits, fruit]);
    } else {
      setSelectedFruits(selectedFruits.filter(f => f !== fruit));
    }
  };


  const handleDialogConfirm = () => {
    setConfirmedFruits([...selectedFruits]);
    setIsDialogOpen(false);
  };

  const handleDialogCancel = () => {
    setIsDialogOpen(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-2xl mx-auto p-8 bg-white rounded-lg shadow-lg">
        <h1 className="text-3xl font-bold text-center mb-4 text-gray-800">
          내가 좋아하는 과일을 선택하세요
        </h1>
        
        <div className="text-center mb-8">
          <div className="inline-flex items-center px-4 py-2 bg-blue-50 border border-blue-200 rounded-lg">
            <span className="text-sm font-medium text-blue-800 mr-2">선택된 과일:</span>
            <span className="text-sm text-blue-700">
              {confirmedFruits.length > 0 ? confirmedFruits.join(", ") : "없음"}
            </span>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4 mb-8">
          {fruits.map((fruit) => (
            <div key={fruit} className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-50">
              <Checkbox.Root
                className="flex h-6 w-6 appearance-none items-center justify-center rounded bg-white border-2 border-gray-300 hover:border-blue-500 focus:border-blue-500 focus:outline-none"
                id={fruit}
                checked={selectedFruits.includes(fruit)}
                onCheckedChange={(checked) => handleFruitChange(fruit, checked as boolean)}
              >
                <Checkbox.Indicator className="text-blue-600">
                  ✓
                </Checkbox.Indicator>
              </Checkbox.Root>
              <Label.Root
                className="text-lg font-medium text-gray-700 cursor-pointer select-none"
                htmlFor={fruit}
              >
                {fruit}
              </Label.Root>
            </div>
          ))}
        </div>

        <Separator.Root className="bg-gray-200 h-px my-6" />
        
        <div className="text-center">
          <Dialog.Root open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <Dialog.Trigger asChild>
              <button
                disabled={selectedFruits.length === 0}
                className="px-8 py-3 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
              >
                확인 ({selectedFruits.length}개 선택됨)
              </button>
            </Dialog.Trigger>
            <Dialog.Portal>
            <Dialog.Overlay className="fixed inset-0 bg-black/50" />
            <Dialog.Content className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white p-6 rounded-lg shadow-xl w-96">
              <Dialog.Title className="text-xl font-bold mb-4 text-gray-800">
                선택 확인
              </Dialog.Title>
              <Dialog.Description className="text-gray-600 mb-6">
                다음 과일들을 선택하셨습니다:
                <div className="mt-2 p-3 bg-gray-100 rounded my-4">
                  <strong>{selectedFruits.join(", ")}</strong>
                </div>
                <Separator.Root className="bg-gray-200 h-px my-4" />
                이대로 진행하시겠습니까?
              </Dialog.Description>
              <div className="flex justify-end gap-3">
                <Dialog.Close asChild>
                  <button
                    onClick={handleDialogCancel}
                    className="px-4 py-2 text-gray-600 border border-gray-300 rounded hover:bg-gray-50 transition-colors"
                  >
                    취소
                  </button>
                </Dialog.Close>
                <button
                  onClick={handleDialogConfirm}
                  className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
                >
                  확인
                </button>
              </div>
            </Dialog.Content>
          </Dialog.Portal>
        </Dialog.Root>
        </div>
      </div>
    </div>
  );
}
